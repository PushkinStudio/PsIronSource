//
//  ISBannerView.h
//  IronSource
//
//  Created by Gili Ariel on 06/04/2017.
//  Copyright © 2017 Gili Ariel. All rights reserved.
//

#import <UIKit/UIKit.h>

@interface ISBannerView : UIView {
}


@end
