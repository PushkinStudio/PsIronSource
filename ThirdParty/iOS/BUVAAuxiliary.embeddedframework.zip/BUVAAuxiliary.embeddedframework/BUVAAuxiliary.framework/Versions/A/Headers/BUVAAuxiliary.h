//
//  BUVAAuxiliary.h
//  BUVAAuxiliary
//
//  Created by bytedance on 2020/8/25.
//  Copyright © 2020 bytedance. All rights reserved.
//

#import <Foundation/Foundation.h>

#import "BUVAAuxiliaryManager.h"

//! Project version number for BUVAAuxiliary.
FOUNDATION_EXPORT double BUVAAuxiliaryVersionNumber;

//! Project version string for BUVAAuxiliary.
FOUNDATION_EXPORT const unsigned char BUVAAuxiliaryVersionString[];

// In this header, you should import all the public headers of your framework using statements like #import <BUVAAuxiliary/PublicHeader.h>


